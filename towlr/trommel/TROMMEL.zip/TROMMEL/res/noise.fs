uniform sampler2D tex;
uniform vec4 offset;

void main ()
{
	vec4 f = texture2D(tex, gl_TexCoord[0].st);
	vec4 smul = vec4(5.0, 3.0, 1.0, 4.0) * 360.0;
	float col;

	f = abs(abs((f + 2.0 * offset) - 1.5) - 1.0);
	f = (sin(radians(f * smul)) + 1.0) / 2.0;
	col = (f.r + f.g + f.b + f.a) / 4.0;
	gl_FragColor = vec4(0.0, col / 2.0, col, 1.0);
}
