DGL( void, glBegin,             (GLenum mode) )
DGL( void, glBindTexture,       (GLenum target, GLuint texture) )
DGL( void, glBlendFunc,         (GLenum sfactor, GLenum dfactor) )
DGL( void, glClear,             (GLbitfield mask) )
DGL( void, glClearColor,        (GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha) )
DGL( void, glColor3f,           (GLfloat red, GLfloat green, GLfloat blue) )
DGL( void, glCopyTexSubImage2D, (GLenum target, GLint level, GLint xoffset, GLint yoffset,
                                 GLint x, GLint y, GLsizei width, GLsizei height) )
DGL( void, glEnable,            (GLenum cap) )
DGL( void, glEnd,               (void) )
DGL( void, glGenTextures,       (GLsizei n, GLuint *textures) )
DGL( void, glLoadIdentity,      (void) )
DGL( void, glMatrixMode,        (GLenum mode) )
DGL( void, glOrtho,             (GLdouble left, GLdouble right, GLdouble bottom,
                                 GLdouble top, GLdouble near_val, GLdouble far_val) )
DGL( void, glPopMatrix,         (void) )
DGL( void, glPushMatrix,        (void) )
DGL( void, glRotatef,           (GLfloat angle, GLfloat x, GLfloat y, GLfloat z) )
DGL( void, glTexCoord2f,        (GLfloat x, GLfloat y) )
DGL( void, glTexImage2D,        (GLenum target, GLint level, GLint internalformat,
                                 GLsizei width, GLsizei height, GLint border,
                                 GLenum format, GLenum type, const GLvoid *pixels) )
DGL( void, glTexParameteri,     (GLenum target, GLenum pname, GLint param) )
DGL( void, glTranslatef,        (GLfloat x, GLfloat y, GLfloat z) )
DGL( void, glVertex2f,          (GLfloat x, GLfloat y) )
DGL( void, glViewport,          (GLint x, GLint y, GLsizei width, GLsizei height) )

DGL( GLenum, glGetError, (void) )

DGLA( void,   glAttachShader,       glAttachObjectARB,        (GLuint program, GLuint shader) )
DGLA( void,   glCompileShader,      glCompileShaderARB,       (GLuint shader) )
DGLA( GLuint, glCreateShader,       glCreateShaderObjectARB,  (GLenum shadertype) )
DGLA( GLuint, glCreateProgram,      glCreateProgramObjectARB, (void) )
DGLA( void,   glDeleteShader,       glDeleteObjectARB,        (GLuint shader) )
DGLA( void,   glDeleteProgram,      glDeleteObjectARB,        (GLuint program) )
DGLA( void,   glGetShaderiv,        glGetObjectParameteriv,   (GLuint shader, GLenum pname, GLint *params) )
DGLA( void,   glGetShaderInfoLog,   glGetInfoLogARB,          (GLuint shader, GLsizei maxlength, GLsizei *length, GLchar *infolog) )
DGLA( void,   glGetProgramiv,       glGetObjectParameteriv,   (GLuint program, GLenum pname, GLint *params) )
DGLA( void,   glGetProgramInfoLog,  glGetInfoLogARB,          (GLuint program, GLsizei maxlength, GLsizei *length, GLchar *infolog) )
DGLA( GLint,  glGetUniformLocation, glGetUniformLocationARB,  (GLuint program, const GLchar *name) )
DGLA( void,   glLinkProgram,        glLinkProgramARB,         (GLuint program) )
DGLA( void,   glShaderSource,       glShaderSourceARB,        (GLuint shader, GLsizei count, const GLchar **string, const GLint *length) )
DGLA( void,   glUseProgram,         glUseProgramObjectARB,    (GLuint program) )
DGLA( void,   glUniform1i,          glUniform1iARB,           (GLint location, GLint v0) )
DGLA( void,   glUniform2f,          glUniform2fARB,           (GLint location, GLfloat v0, GLfloat v1) )
DGLA( void,   glUniform4f,          glUniform4fARB,           (GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3) )

#undef DLIB
#undef DSYMX
#undef DGL
#undef DGLA
