#define TITLE "TROMMEL"
#define SCREEN_W 256
#define SCREEN_H 256
#define LOGIC_HZ 60
#define BORDER_W 4
#define BORDER_H 96
#define TWOPI 6.28318530717958647692

#define WINOFF 22
#define ROTOFF 180
#define ROTOFF2 135
#define ROTOFF3 90
#define WINANGLE 90
#define BOXOFF 12

#include "audio.h"
#include "dyn.h"
#include "shader.h"
#include "sys.h"
#include "texture.h"

#include "SDL.h"
#include "SDL_opengl.h"
#ifdef __WIN32__
#include <windows.h>
#include <direct.h>
#endif
#ifdef __linux__
#include <unistd.h>
#endif
#include <stdio.h>
#include <math.h>
#include <string.h>

#define panic(x,y) _panic(__FILE__, __LINE__, (x), (y))

static unsigned int _desktop_w, _desktop_h, _screen_w, _screen_h, _window_w, _window_h;
static GLfloat _noiseoffset = 0.0f;
static GLint _noiseoffsetuniform, _noisetexuniform;
static unsigned int _zoom;
static int _totalscore, _score, _tries, _usescore;
static int _init_ok = 0;

static struct {
	int rotating;
	int blink;
	int win;
	float angle;
	float rangle, rangle2, rangle3;
	int scrangle;
	int dist;
} _cur, _prev;

void _panic (const char *file, unsigned int line, const char *what, const char *why)
{
	char buf[256];
	snprintf(buf, sizeof(buf), "[%s:%u] panic! %s: %s", file, line, what, why);
#ifdef __WIN32__
	MessageBoxA(NULL, buf, TITLE, MB_ICONEXCLAMATION);
#endif
	fprintf(stderr, "%s\n", buf);
	exit(1);
}

static void read_score (void)
{
	FILE *fp = fopen("score.txt", "r");
	_totalscore = 0;
	_usescore = 0;
	if (fp)
	{
		fscanf(fp, "%i", &_totalscore);
		fclose(fp);
		_usescore = 1;
	}
}

static void write_score (void)
{
	if (_usescore)
	{
		FILE *fp = fopen("score.txt", "w");
		if (fp)
		{
			if (_cur.win)
				_totalscore += _score;
			fprintf(fp, "%i\n", _totalscore);
			fclose(fp);
		}
	}
}

static unsigned int min_u (unsigned int a, unsigned int b)
{
	return a < b ? a : b;
}

static int abs_i (int a)
{
	return a < 0 ? -a : a;
}

static void resize (unsigned int w, unsigned int h)
{
	static char envbuf[64];
	unsigned int ww, wh;

	_zoom = min_u((_desktop_w - BORDER_W) / w, (_desktop_h - BORDER_H) / h);
	if (!_zoom) _zoom = 1;

	ww = w * _zoom;
	wh = h * _zoom;

	snprintf(envbuf, sizeof(envbuf), "SDL_VIDEO_WINDOW_POS=%i,%i",
		(_desktop_w - ww) / 2, (_desktop_h - wh) / 2);
	SDL_putenv(envbuf);

	if (!SDL_SetVideoMode(_window_w = ww, _window_h = wh, 0, SDL_OPENGL))
		panic("couldn't set videomode", SDL_GetError());

	_screen_w = w;
	_screen_h = h;

	if (!D.loaded)
		dyn_load();

	init_screen_tex(w, h);

	D.glMatrixMode(GL_PROJECTION);
	D.glLoadIdentity();
	D.glOrtho(0, w, 0, h, -1, 1);
	D.glMatrixMode(GL_MODELVIEW);
	D.glLoadIdentity();
	//D.glScalef(1.0, -1.0, 1.0);

	D.glEnable(GL_TEXTURE_2D);
	D.glEnable(GL_BLEND);
}

static void quit (void)
{
	if (_init_ok)
		write_score();
	quit_audio();
	if (SDL_WasInit(SDL_INIT_EVERYTHING))
	{
		SDL_ShowCursor(SDL_ENABLE);
		SDL_Quit();
	}
}

static int iframe (void)
{
	SDL_Event e;

	while (SDL_PollEvent(&e)) switch (e.type)
	{
		case SDL_QUIT:
			return 0;

		case SDL_KEYDOWN:
			if (e.key.keysym.sym == SDLK_ESCAPE)
				return 0;
			break;

		case SDL_MOUSEBUTTONDOWN:
			_cur.blink = 0x0c;
			if (_cur.win)
				break;
			if (!_cur.rotating)
			{
				switch (e.button.button)
				{
					case SDL_BUTTON_LEFT:
						--_score;
						++_tries;
						_cur.rotating = 1;
						_prev.angle = _cur.angle = 0.0f;
						play_sample(&_sample.rotate);
						break;
					case SDL_BUTTON_RIGHT:
						--_score;
						++_tries;
						_cur.rotating = -1;
						_prev.angle = _cur.angle = 0.0f;
						play_sample(&_sample.rotate2);
						break;
					default: break;
				}
				if (_score < 0)
					_score = 0;
				if (e.button.x / _zoom == _screen_w / 2 &&
					e.button.y / _zoom == _screen_h / 2)
				{
					_cur.rotating *= 2;
				}
			}
			break;

		default: break;
	}

	return 1;
}

static unsigned int lframe (void)
{
	int alive;
	_prev = _cur;

	alive = iframe();

	if ((_noiseoffset += 0.001f) >= 1.0f)
		_noiseoffset -= 1.0f;

	if ((_cur.rangle -= 1.0f) < 0.0f)
	{
		_cur.rangle += 360.0f;
		_prev.rangle += 360.0f;
	}

	if ((_cur.rangle2 += 0.9f) >= 360.0f)
	{
		_cur.rangle2 -= 360.0f;
		_prev.rangle2 -= 360.0f;
	}

	if ((_cur.rangle3 -= 0.6f) <= 0.0f)
	{
		_cur.rangle3 += 360.0f;
		_prev.rangle3 += 360.0f;
	}

	if (fabsf(_cur.rangle - _cur.scrangle) <= 20.0f && _cur.dist >= (ROTOFF-20) && _cur.dist < (ROTOFF+20))
	{
		_cur.scrangle = 0;
		_cur.dist = 3 * 45;
		play_sample(&_sample.bump);
	}

	if (fabsf(_cur.rangle2 - _cur.scrangle) <= 10.0f && _cur.dist >= (ROTOFF2-20) && _cur.dist < (ROTOFF2+20))
	{
		_cur.scrangle = 0;
		_cur.dist = 3 * 45;
		play_sample(&_sample.bump);
	}

	if (fabsf(_cur.rangle3 - _cur.scrangle) <= 5.0f && _cur.dist >= (ROTOFF3-20) && _cur.dist < (ROTOFF3+20))
	{
		_cur.scrangle = 0;
		_cur.dist = 3 * 45;
		play_sample(&_sample.bump);
	}

	if (_cur.rotating)
	{
		if (_cur.rotating > 0)
		{
			if (_cur.rotating == 1 && --_cur.dist < 0)
				_cur.dist = 0;

			if ((_cur.angle += 2) >= 90)
			{
				if (_cur.rotating > 1 && (_cur.scrangle -= 90) == -90)
					_cur.scrangle = 270;
				_cur.rotating = 0;
				_prev.angle -= 90;
				_cur.angle = 0;
			}
		}
		else
		{
			if (_cur.rotating == -1 && ++_cur.dist >= 4 * 45)
				_cur.dist = 4 * 45;

			if ((_cur.angle -= 2) <= -90)
			{
				if (_cur.rotating < -1 && (_cur.scrangle += 90) == 360)
					_cur.scrangle = 0;
				_cur.rotating = 0;
				_prev.angle += 90;
				_cur.angle = 0;
			}
		}
	}
	else if (_cur.scrangle == WINANGLE && !_cur.win &&
		abs_i(_cur.dist - WINOFF) < 8)
	{
		_cur.dist = WINOFF;
		_cur.blink = 0x0c;
		_cur.win = 1;
		play_sample(&_sample.win);
	}

	++_cur.blink;

	return alive * LOGIC_HZ;
}

static float fractf (float x)
{
	return x - floorf(x);
}

static void set_noise_offset (void)
{
	float offset1 = fractf(_noiseoffset);
	float offset2 = fractf(offset1 + 0.5f);
	float offset3 = fractf(offset1 + 0.25f);
	float offset4 = fractf(offset1 + 0.75f);
	D.glUniform4f(_noiseoffsetuniform, offset1, offset2, offset3, offset4);
}

static void print_number (int num, float x, float y, float angle)
{
	int negative = num < 0;
	if (negative)
		num = -num;

	do {
		use_texture(&_tex.n[num % 10]);
		draw_texture(x, y, angle);
		x -= 8;
		num /= 10;
	} while (num);
}

static float interpolate (float a, float b, float f)
{
	return (a * (1.0f - f) + b * f) / 1.0f;
}

static void vframe (unsigned int mille)
{
	float f = mille / 1000.0f;
	float angle = interpolate(_prev.angle, _cur.angle, f);
	int mx, my;
	int vx = (_window_w - _screen_w) / 2;
	int vy = (_window_h - _screen_h) / 2;
	int hold = (_cur.rotating > 1) || (_cur.rotating < -1);
	float scrangle = hold ? _cur.scrangle - angle : _cur.scrangle;
	float rangle = interpolate(_prev.rangle, _cur.rangle, f);
	float rangle2 = interpolate(_prev.rangle2, _cur.rangle2, f);
	float rangle3 = interpolate(_prev.rangle3, _cur.rangle3, f);
	float dist = interpolate(_prev.dist, _cur.dist, f) / 2.0f + BOXOFF;

	D.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	D.glClear(GL_COLOR_BUFFER_BIT);

	D.glViewport(vx, vy, _screen_w, _screen_h);
	D.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	use_program(_shader.noise);
	D.glUniform1i(_noisetexuniform, 0);
	set_noise_offset();
	use_texture(&(_tex.noise));
	draw_texture(_screen_w / 2, _screen_h / 2, scrangle);
	use_program(0);

	D.glPushMatrix();
	D.glTranslatef(_screen_w / 2, _screen_h / 2, 0.0f);
	D.glRotatef(WINANGLE, 0.0, 0.0, 1.0);
	use_texture(&_tex.box);
	draw_texture(_screen_w / 2 - (WINOFF / 2.0f + BOXOFF), _screen_w / 2 - (WINOFF / 2.0f + BOXOFF), 0.0f);
	D.glPopMatrix();

	D.glPushMatrix();
	D.glTranslatef(_screen_w / 2, _screen_h / 2, 0.0f);
	D.glRotatef(rangle, 0.0, 0.0, 1.0);
	use_texture(&_tex.key);
	draw_texture(_screen_w / 2 - (ROTOFF / 2.0f + BOXOFF), _screen_w / 2 - (ROTOFF / 2.0f + BOXOFF), 0.0f);
	D.glPopMatrix();

	D.glPushMatrix();
	D.glTranslatef(_screen_w / 2, _screen_h / 2, 0.0f);
	D.glRotatef(rangle2, 0.0, 0.0, 1.0);
	use_texture(&_tex.key);
	draw_texture(_screen_w / 2 - (ROTOFF2 / 2.0f + BOXOFF), _screen_w / 2 - (ROTOFF2 / 2.0f + BOXOFF), 0.0f);
	D.glPopMatrix();

	D.glPushMatrix();
	D.glTranslatef(_screen_w / 2, _screen_h / 2, 0.0f);
	D.glRotatef(rangle3, 0.0, 0.0, 1.0);
	use_texture(&_tex.key);
	draw_texture(_screen_w / 2 - (ROTOFF3 / 2.0f + BOXOFF), _screen_w / 2 - (ROTOFF3 / 2.0f + BOXOFF), 0.0f);
	D.glPopMatrix();

	D.glPushMatrix();
	D.glTranslatef(_screen_w / 2, _screen_h / 2, 0.0f);
	D.glRotatef(scrangle, 0.0, 0.0, 1.0);
	use_texture(&_tex.key);
	draw_texture(_screen_w / 2 - dist, _screen_w / 2 - dist, 0.0f);
	D.glPopMatrix();

	if (_cur.win)
	{
		if (_cur.blink & 16)
		{
			use_texture(&_tex.cake);
			draw_texture(_screen_w / 2, _screen_h / 2, 0.0f);
		}
	}
	else
	{
		use_texture(&_tex.cross);
		draw_texture(_screen_w / 2, _screen_h / 2, hold ? 0.0f : angle);
	}

	if (_usescore)
	{
		print_number(_totalscore + _score, _screen_w - 7, 8, 0.0f);
		print_number(_score, _screen_w - 7, 18, 0.0f);
	}
	if (!_cur.win || ((_cur.blink - 0x08) & 16))
		print_number(_tries, _screen_w - 7, _usescore ? 28 : 8, 0.0f);

	use_texture(&_tex.ball);
	SDL_GetMouseState(&mx, &my);
	draw_texture(mx / _zoom, my / _zoom, 0.0f);

	D.glBlendFunc(GL_ONE, GL_ZERO);

	use_texture(&_tex.screen);
	D.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, vx, vy, _screen_w, _screen_h);
	D.glViewport(0, 0, _window_w, _window_h);
	draw_texture_yflip(_screen_w / 2, _screen_h / 2, 0.0f);
	SDL_GL_SwapBuffers();
}

static void loop (void)
{
	unsigned int ltrigger = 0, logichz = lframe();
	Uint32 now, then = SDL_GetTicks();

	while (logichz)
	{
		while (logichz && ((ltrigger += ((now = SDL_GetTicks()) - then) * logichz) >= 1000))
		{
			then = now;
			ltrigger -= 1000;
			logichz = lframe();
		}
		then = now;

		vframe(ltrigger);
		SDL_Delay(10);
	}
}

static void init_dir (void)
{
	char buffer[65536];
	int ok = 0;
#ifdef __WIN32__
	wchar_t wbuffer[65536];
	unsigned int len = GetModuleFileNameW(NULL, wbuffer, sizeof(buffer));
	if (len)
	{
		unsigned int i = len;
		while (i--)
		{
			if (wbuffer[i] == '\\' || wbuffer[i] == '/')
			{
				wbuffer[i] = 0;
				ok = (_wchdir(wbuffer) == 0);
				break;
			}
		}
		for (i = 0; i <= len; ++i)
			buffer[i] = (char)wbuffer[i];
	}
	if (!ok)
	{
		unsigned int len = GetModuleFileNameA(NULL, buffer, sizeof(buffer));
		if (len)
		{
			unsigned int i = len;
			while (i--)
			{
				if (buffer[i] == '\\' || buffer[i] == '/')
				{
					buffer[i] = 0;
					ok = (_chdir(buffer) == 0);
					break;
				}
			}
		}

	}
#elif defined(__linux__)
	unsigned int len = readlink("/proc/self/exe", buffer, sizeof(buffer) - 1);
	unsigned int i = len;
	buffer[i] = 0;
	while (i--)
	{
		if (buffer[i] == '/')
		{
			buffer[i] = 0;
			ok = (chdir(buffer) == 0);
			break;
		}
	}
#else
#error need some code for this os
#endif

	//if (ok) fprintf(stderr, "changed dir to \"%s\"\n", buffer);
}

static void init (void)
{
	const SDL_version *version;
	const SDL_VideoInfo *vi;

	dyn_init();
	atexit(quit);

	init_dir();

	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0)
		panic("couldn't init SDL", SDL_GetError());

	version = SDL_Linked_Version();
	if (version->major < 1 || (version->major == 1 &&
		(version->minor < 2 || (version->minor == 2 &&
		  version->patch < 10))))
		panic("SDL too old", "1.2.10 or newer required");

	vi = SDL_GetVideoInfo();
	_desktop_w = vi->current_w;
	_desktop_h = vi->current_h;

	SDL_GL_SetAttribute(SDL_GL_SWAP_CONTROL, 1);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
	SDL_WM_SetCaption(TITLE, TITLE);
	set_icon("res/icon.png");
	resize(SCREEN_W, SCREEN_H);

	init_audio();

	SDL_ShowCursor(SDL_DISABLE);

	make_2d_noise_mip_tex(&_tex.noise, 256);
	load_texture(&_tex.cross, "res/cross.png");
	load_texture(&_tex.ball, "res/ball.png");
	load_texture(&_tex.n[0], "res/0.png");
	load_texture(&_tex.n[1], "res/1.png");
	load_texture(&_tex.n[2], "res/2.png");
	load_texture(&_tex.n[3], "res/3.png");
	load_texture(&_tex.n[4], "res/4.png");
	load_texture(&_tex.n[5], "res/5.png");
	load_texture(&_tex.n[6], "res/6.png");
	load_texture(&_tex.n[7], "res/7.png");
	load_texture(&_tex.n[8], "res/8.png");
	load_texture(&_tex.n[9], "res/9.png");
	load_texture(&_tex.cake, "res/cake.png");
	load_texture(&_tex.box, "res/box.png");
	load_texture(&_tex.key, "res/key.png");

	load_shaders();
	_noiseoffsetuniform = D.glGetUniformLocation(_shader.noise, "offset");
	_noisetexuniform = D.glGetUniformLocation(_shader.noise, "tex");

	_totalscore = 0;
	_score = 1000;
	_tries = 0;
	read_score();

	memset(&_cur, 0, sizeof(_cur));
	memset(&_prev, 0, sizeof(_prev));
	_cur.dist = 3 * 45;

	play_music(&_sample.bg);

	_init_ok = 1;
}

int main (int argc, char *argv[])
{
	(void)argc; (void)argv;

	init();
	loop();
	return 0;
}
