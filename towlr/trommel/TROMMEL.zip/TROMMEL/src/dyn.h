#ifndef INCLUDE_DYN_H
#define INCLUDE_DYN_H

#include "SDL_opengl.h"

typedef struct {
#define DLIB(name, file)
#define DSYMX(lib, ret, name, args) ret (*name) args;
#ifdef __WIN32__
#define DGL(ret, name, args) GLAPI ret APIENTRY (*name) args;
#define DGLA(ret, name, alt, args) GLAPI ret APIENTRY (*name) args;
#else
#define DGL(ret, name, args) ret APIENTRY (*name) args;
#define DGLA(ret, name, alt, args) ret APIENTRY (*name) args;
#endif
#include "dynsyms.h"
	int loaded;
} DynSyms;

extern DynSyms D;

void dyn_init (void);
void dyn_load (void);

#endif
