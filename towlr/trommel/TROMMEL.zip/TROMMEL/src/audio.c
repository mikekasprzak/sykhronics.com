#include "audio.h"
#include "sys.h"

Samples _sample;

static int _init_mix = 0;
static int _channel = 0;

void load_sample (Sample *sample, const char *filename)
{
	sample->chunk = Mix_LoadWAV(filename);
	if (!sample->chunk)
		panic("couldn't load sample", filename);
	sample->channel = _channel++;
}

static void free_chunk (Mix_Chunk **chunk)
{
	if (*chunk)
	{
		Mix_FreeChunk(*chunk);
		*chunk = NULL;
	}
}

void play_music (Sample *sample)
{
	Mix_PlayChannel(sample->channel, sample->chunk, -1);
}

void play_sample (Sample *sample)
{
	Mix_PlayChannel(sample->channel, sample->chunk, 0);
}

void init_audio (void)
{
	if (Mix_OpenAudio(44100, AUDIO_S16SYS, 2, 2048))
		panic("couldn't init audio", Mix_GetError());

	_init_mix = 1;
	_channel = 0;
	load_sample(&_sample.bg, "res/bg.ogg");
	load_sample(&_sample.rotate, "res/r1.ogg");
	load_sample(&_sample.rotate2, "res/r2.ogg");
	load_sample(&_sample.win, "res/ding.ogg");
	load_sample(&_sample.bump, "res/dong.ogg");
}

void quit_audio (void)
{
	if (_init_mix)
	{
		free_chunk(&_sample.bg.chunk);
		Mix_CloseAudio();
		_init_mix = 0;
	}
}
