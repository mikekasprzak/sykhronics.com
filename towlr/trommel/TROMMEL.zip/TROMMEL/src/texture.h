#ifndef INCLUDE_TEXTURE_H
#define INCLUDE_TEXTURE_H

#include "SDL_opengl.h"

typedef struct {
	GLuint tex;
	float w, h;
	float tw, th;
	float ow, oh;
} Texture;

typedef struct {
	Texture screen;
	Texture noise;
	Texture cross;
	Texture ball;
	Texture cake;
	Texture box;
	Texture key;
	Texture n[10];
} Textures;
extern Textures _tex;

void draw_texture (float x, float y, float angle);
void draw_texture_yflip (float x, float y, float angle);

void use_texture (const Texture *tex);
void load_texture (Texture *tex, const char *filename);
void make_2d_noise_mip_tex (Texture *tex, unsigned int size);

void init_screen_tex (unsigned int w, unsigned int h);

void set_icon (const char *filename);

#endif
