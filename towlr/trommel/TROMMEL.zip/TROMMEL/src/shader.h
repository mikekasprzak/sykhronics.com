#ifndef INCLUDE_SHADER_H
#define INCLUDE_SHADER_H

#include "dyn.h"
#include "SDL_opengl.h"

struct {
	GLuint noise;
} _shader;

void load_shaders (void);
void use_program (GLuint program);

#endif
