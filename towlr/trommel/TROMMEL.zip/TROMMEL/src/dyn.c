#include "dyn.h"
#include "sys.h"
#include "SDL.h"
#include <string.h>

DynSyms D;

static void * getglproc (const char *name)
{
	void *sym = SDL_GL_GetProcAddress(name);
	if (!sym)
		panic("missing symbol (opengl 1.5+ required)", name);
	return sym;
}

static void * getglproca (const char *name, const char *alt)
{
	void *sym = SDL_GL_GetProcAddress(name);
	return sym ? sym : getglproc(alt);
}

void dyn_init (void)
{
	memset(&D, 0, sizeof(D));
}

void dyn_load (void)
{
#define DLIB(name, file) void *l##name = SDL_LoadObject(file);
#define DSYMX(lib, ret, name, args) D.name = SDL_LoadFunction(l##lib, name);
#define DGL(ret, name, args) D.name = getglproc(#name);
#define DGLA(ret, name, alt, args) D.name = getglproca(#name, #alt);
#include "dynsyms.h"
}
