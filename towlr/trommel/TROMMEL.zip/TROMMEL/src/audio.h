#ifndef INCLUDE_AUDIO_H
#define INCLUDE_AUDIO_H

#include "SDL_mixer.h"

typedef struct {
	Mix_Chunk *chunk;
	int channel;
} Sample;

typedef struct {
	Sample bg;
	Sample rotate;
	Sample rotate2;
	Sample win;
	Sample bump;
} Samples;

extern Samples _sample;

void load_sample (Sample *sample, const char *filename);
void play_music (Sample *sample);
void play_sample (Sample *sample);

void init_audio (void);
void quit_audio (void);

#endif
