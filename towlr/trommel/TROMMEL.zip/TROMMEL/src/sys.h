#ifndef INCLUDE_SYS_H
#define INCLUDE_SYS_H

#define panic(x,y) _panic(__FILE__, __LINE__, (x), (y))
void _panic (const char *file, unsigned int line, const char *what, const char *why);

float rndf (void);

#endif
