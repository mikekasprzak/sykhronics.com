#include "dyn.h"
#include "sys.h"
#include "texture.h"

#include "SDL_opengl.h"
#include "SDL_image.h"

Textures _tex;

static const Texture *curtex;
static GLuint _program = 0;

static Uint32 _seed = 41;

/* stupid but os-neutral =P */
static Uint32 rnd (void)
{
	return (_seed = 1103515245 * _seed + 12345);
}

static unsigned int twopow (unsigned int v)
{
	unsigned int bit = 2;
	if (--v & 0xffff0000) { v >>= 16; bit <<= 16; }
	if (v & 0x0000ff00) { v >>= 8; bit <<= 8; }
	if (v & 0x000000f0) { v >>= 4; bit <<= 4; }
	if (v & 0x0000000c) { v >>= 2; bit <<= 2; }
	if (v & 0x00000002) { bit <<=  1; }
	return bit;
}

void draw_texture (float x, float y, float angle)
{
	if (curtex)
	{
		const float x1 = -curtex->w / 2 + 0.05f;
		const float y1 = -curtex->h / 2 + 0.05f;
		const float x2 = x1 + curtex->w;
		const float y2 = y1 + curtex->h;

		D.glPushMatrix();
		D.glTranslatef(x, y, 0.0f);
		D.glRotatef(angle, 0.0f, 0.0f, 1.0f);

		D.glBegin(GL_QUADS);
		D.glTexCoord2f(0.0f, 0.0f);
		D.glVertex2f(x1, y1);
		D.glTexCoord2f(0.0f, curtex->th);
		D.glVertex2f(x1, y2);
		D.glTexCoord2f(curtex->tw, curtex->th);
		D.glVertex2f(x2, y2);
		D.glTexCoord2f(curtex->tw, 0.0f);
		D.glVertex2f(x2, y1);
		D.glEnd();

		D.glPopMatrix();
	}
}

void draw_texture_yflip (float x, float y, float angle)
{
	if (curtex)
	{
		const float x1 = -curtex->w / 2 + 0.05f;
		const float y1 = -curtex->h / 2 + 0.05f;
		const float x2 = x1 + curtex->w;
		const float y2 = y1 + curtex->h;

		D.glPushMatrix();
		D.glTranslatef(x, y, 0.0f);
		D.glRotatef(angle, 0.0f, 0.0f, 1.0f);

		D.glBegin(GL_QUADS);
		D.glTexCoord2f(0.0f, curtex->th);
		D.glVertex2f(x1, y1);
		D.glTexCoord2f(0.0f, 0.0f);
		D.glVertex2f(x1, y2);
		D.glTexCoord2f(curtex->tw, 0.0f);
		D.glVertex2f(x2, y2);
		D.glTexCoord2f(curtex->tw, curtex->th);
		D.glVertex2f(x2, y1);
		D.glEnd();

		D.glPopMatrix();
	}
}

void use_program (GLuint program)
{
	if (_program != program)
	{
		D.glUseProgram(_program = program);
	}
}

void use_texture (const Texture *tex)
{
	if (curtex != tex)
	{
		curtex = tex;
		D.glBindTexture(GL_TEXTURE_2D, tex->tex);
	}
}

static void new_texture (Texture *tex, const void *pixels, unsigned int w, unsigned int h)
{
	const unsigned int w2 = twopow(w), h2 = twopow(h);
	tex->tw = ((tex->w = (float)w)) / w2;
	tex->th = ((tex->h = (float)h)) / h2;

	D.glGenTextures(1, &(tex->tex));
	use_texture(tex);
	D.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	D.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	D.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	D.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	D.glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w2, h2, 0, GL_RGBA,
			GL_UNSIGNED_BYTE, pixels);
}

void load_texture (Texture *tex, const char *filename)
{
	SDL_Surface *tmp = IMG_Load(filename), *s;
	if (!tmp) panic("couldn't load image", filename);

	s = SDL_CreateRGBSurface(0, twopow(tmp->w), twopow(tmp->h), 32,
			0xff, 0xff00, 0xff0000, 0xff000000);
	if (!s) panic("out of memory", filename);

	SDL_SetAlpha(tmp, 0, 0);
	SDL_BlitSurface(tmp, NULL, s, NULL);

	new_texture(tex, s->pixels, tmp->w, tmp->h);

	SDL_FreeSurface(tmp);
	SDL_FreeSurface(s);
}

void init_screen_tex (unsigned int w, unsigned int h)
{
	unsigned int w2 = twopow(w), h2 = twopow(h);
	Uint32 pixels[w2 * h2];
	memset(pixels, 0, sizeof(pixels));
	new_texture(&_tex.screen, pixels, w, h);
}

static int get_spline_s (int i2, int i1, int i0)
{
	return 6 * ((i2 - i1) - (i1 - i0));
}

static Uint8 get_spline_point (Uint8 px0, Uint8 px1, Uint8 px2, Uint8 px3, float x)
{
	const float s1 = get_spline_s(px2, px1, px0);
	const float s2 = get_spline_s(px3, px2, px1);
	const float a = (s2 - s1) / 6.0f;
	const float b = s1 / 2.0f;
	const float c = (px2 - px1) - (2.0f*s1 + s2) / 6.0f;
	const float d = px1;
	const int px = (int)((d + x * (c + x * (b + x * a))) / 2.0 + 0.5f);
	return px < 0 ? 0 : px > 255 ? 255 : px;
}

unsigned int interpolate_point (Uint8 *pixels, unsigned int size, unsigned int scale,
	unsigned int x, unsigned int y)
{
	const float fx = (x & (scale - 1)) / (float)(scale);
	const float fy = (y & (scale - 1)) / (float)(scale);
	unsigned int i = x & ~(scale - 1), j = y & ~(scale - 1);
	const unsigned int i0 = (i - scale) % size;
	const unsigned int i1 = i;
	const unsigned int i2 = (i + scale) % size;
	const unsigned int i3 = (i + 2*scale) % size;
	const unsigned int j0 = (j - scale) % size;
	const unsigned int j1 = j;
	const unsigned int j2 = (j + scale) % size;
	const unsigned int j3 = (j + 2*scale) % size;
	Uint8 ph0, ph1, ph2, ph3, *pix;

	pix = &pixels[j0 * size];
	ph0 = get_spline_point(pix[i0], pix[i1], pix[i2], pix[i3], fx);
	pix = &pixels[j1 * size];
	ph1 = get_spline_point(pix[i0], pix[i1], pix[i2], pix[i3], fx);
	pix = &pixels[j2 * size];
	ph2 = get_spline_point(pix[i0], pix[i1], pix[i2], pix[i3], fx);
	pix = &pixels[j3 * size];
	ph3 = get_spline_point(pix[i0], pix[i1], pix[i2], pix[i3], fx);

	return get_spline_point(ph0, ph1, ph2, ph3, fy);
}
/*
static Uint32 mix_pixel_2 (Uint8 *pixels, unsigned int size,
	unsigned int x, unsigned int y)
{
	//return pixels[y * size + x];
	//return interpolate_point(pixels, size, 64, x, y);
	return (Uint8)((interpolate_point(pixels, size, 64, x, y)
				+ interpolate_point(pixels, size, 32, x, y)) / 2);
}
*/
static Uint32 mix_pixel_4 (Uint8 *pixels, unsigned int size,
	unsigned int x, unsigned int y)
{
	return (Uint8)((interpolate_point(pixels, size, 64, x, y)
				+ interpolate_point(pixels, size, 32, x, y)
				+ interpolate_point(pixels, size, 16, x, y)
				+ interpolate_point(pixels, size, 1, x, y)) / 4);
}

static Uint32 mix_pixel_8 (Uint8 *pixels, unsigned int size,
	unsigned int x, unsigned int y)
{
	return (Uint8)((interpolate_point(pixels, size, 128, x, y)
				+ interpolate_point(pixels, size, 64, x, y)
				+ interpolate_point(pixels, size, 32, x, y)
				+ interpolate_point(pixels, size, 16, x, y)
				+ interpolate_point(pixels, size, 8, x, y)
				+ interpolate_point(pixels, size, 4, x, y)
				+ interpolate_point(pixels, size, 2, x, y)
				+ interpolate_point(pixels, size, 1, x, y)) / 8);
}

void make_2d_noise_mip_tex (Texture *tex, unsigned int size)
{
	Uint8 pixels[4][size * size];
	Uint32 pixels32[size * size];
	unsigned x, y, i, mip = 0;

	tex->w = tex->h = size;
	tex->tw = tex->th = 1.0f;

	D.glGenTextures(1, &(tex->tex));
	D.glBindTexture(GL_TEXTURE_2D, tex->tex);
	D.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	D.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	D.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	D.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR/*_MIPMAP_LINEAR*/);

	//for (mip = 0; size; size >>= 1, ++mip)
	{
		for (i = y = 0; y < size; ++y)
		{
			for (x = 0; x < size; ++x, ++i)
			{
				pixels[0][i] = ((rnd() >> 16) & 0xff);
				pixels[1][i] = ((rnd() >> 16) & 0xff);
				pixels[2][i] = ((rnd() >> 16) & 0xff);
				pixels[3][i] = ((rnd() >> 16) & 0xff);
			}
		}
		for (i = y = 0; y < size; ++y)
			for (x = 0; x < size; ++x, ++i)
				pixels32[i] = mix_pixel_4(pixels[0], size, x, y)
						| (mix_pixel_4(pixels[1], size, x, y) << 8)
						| (mix_pixel_4(pixels[2], size, x, y) << 16)
						| (mix_pixel_8(pixels[3], size, x, y) << 24);
		D.glTexImage2D(GL_TEXTURE_2D, mip, GL_RGBA, size, size, 0, GL_RGBA,
				GL_UNSIGNED_BYTE, pixels32);
	}
}

void set_icon (const char *filename)
{
	SDL_Surface *icon = IMG_Load(filename);
	if (icon)
	{
		SDL_WM_SetIcon(icon, NULL);
		SDL_FreeSurface(icon);
	}
}
