#include "dyn.h"
#include "shader.h"
#include "sys.h"
#include <stdio.h>
#include <malloc.h>
#include <string.h>

static char _log[65536] = { '\n' };
static GLsizei _foo;

static inline GLint get_shader (GLuint shader, GLenum pname)
{
	GLint r;
	D.glGetShaderiv(shader, pname, &r);
	return r;
}

static inline GLint get_program (GLuint program, GLenum pname)
{
	GLint r;
	D.glGetProgramiv(program, pname, &r);
	return r;
}

static void print_shader_log (GLuint shader, int fragment)
{
	D.glGetShaderInfoLog(shader, sizeof(_log) - 1, &_foo, _log + 1);
	if (_foo)
		fprintf(stderr, "%s:%s", fragment ? "fragment shader log" : "vertex shader log", _log);
}

static void print_program_log (GLuint program)
{
	D.glGetShaderInfoLog(program, sizeof(_log) - 1, &_foo, _log + 1);
	if (_foo)
		fprintf(stderr, "%s:%s", "program log", _log);
}

static void shader_error (GLuint shader, int fragment)
{
	D.glGetShaderInfoLog(shader, sizeof(_log) - 1, &_foo, _log + 1);
	panic(fragment ? "fragment shader error" : "vertex shader error", _log);
}

static void program_error (GLuint program)
{
	D.glGetProgramInfoLog(program, sizeof(_log) - 1, &_foo, _log + 1);
	panic("shader link error", _log);
}

static GLuint compile_shader (const char *source, int fragment)
{
	GLuint shader = D.glCreateShader(fragment ? GL_FRAGMENT_SHADER : GL_VERTEX_SHADER);
	if (!shader)
		panic("couldn't create shader", "check gfx driver?");
	D.glShaderSource(shader, 1, &source, NULL);
	D.glCompileShader(shader);
	if (!get_shader(shader, GL_COMPILE_STATUS))
		shader_error(shader, fragment);
	print_shader_log(shader, fragment);
	return shader;
}

GLuint make_shader (const char *vsource, const char *fsource)
{
	GLuint vs, fs, program;

	/*fprintf(stderr, "[vertex shader]\n%s\n[fragment shader]\n%s\n",
		vsource, fsource);*/

	vs = compile_shader(vsource, 0);
	fs = compile_shader(fsource, 1);
	program = D.glCreateProgram();

	if (!program)
		panic("couldn't create shader program", "no idea why");
	D.glAttachShader(program, vs);
	D.glAttachShader(program, fs);
	D.glLinkProgram(program);
	if (!get_program(program, GL_LINK_STATUS))
		program_error(program);
	print_program_log(program);
	D.glDeleteShader(vs);
	D.glDeleteShader(fs);
	return program;
}

static char *load_file (const char *filename)
{
	FILE *fp = fopen(filename, "r");
	char *buf;
	long size;

	if (!fp)
		panic("couldn't open file", filename);
	if (fseek(fp, 0, SEEK_END) || (size = ftell(fp)) < 0)
		panic("error accessing file", filename);
	rewind(fp);

	buf = malloc((size_t)size + 1);
	if (!buf)
		panic("out of memory", filename);

	if (!fread(buf, size, 1, fp))
		panic("error reading file", filename);
	buf[size] = 0;

	fclose(fp);
	return buf;
}

GLuint load_shader (const char *name)
{
	unsigned int namelen = strlen(name);
	char buf[namelen + 7];
	char *vsource, *fsource;
	GLuint program;

	strcpy(buf, "res/");
	strcpy(buf + 4, name);
	strcpy(buf + 4 + namelen, ".vs");
	vsource = load_file(buf);
	buf[namelen + 5] = 'f';
	fsource = load_file(buf);
	program = make_shader(vsource, fsource);
	free(vsource);
	free(fsource);
	return program;
}

void load_shaders (void)
{
	_shader.noise = load_shader("noise");
}
