#include "game.h"

#include <iostream>

#include <math.h>

#include <GL/gl.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>

using namespace std;

bool game_exit = 0;

Mix_Chunk* SND_BLOK = 0;
Mix_Chunk* SND_DEAD = 0;
Mix_Chunk* SND_LASR = 0;
Mix_Chunk* SND_MOVE = 0;

int CHNL_MOVE = 0;
int CHNL_DEAD = 1;
int CHNL_LASR = 2;
int CHNL_BLOK = 3;

int BLVL;
int SO;
double SC;
int WIN;

void colr (int CID) {

   double CTBL[][4] = {

      { 0, 0, 0, 1 },
      { 1, 0, 0, 1 },
      { 0, 1, 0, 1 },
      { 0, 0, 1, 1 },
      { 1, 1, 0, 1 },
      { 1, 0, 1, 1 },
      { 0, 1, 1, 1 },
      { 1, 1, 1, 1 },
   };

   double* C = CTBL[CID];

   glColor4f (C[0], C[1], C[2], C[3]);
};

void quad (int X, int Y, int W, int H) {

   // draw the cross
   glBegin (GL_QUADS);
   glVertex3f (X - W, Y - H, -.1);
   glVertex3f (X + W, Y - H, -.1);
   glVertex3f (X + W, Y + H, -.1);
   glVertex3f (X - W, Y + H, -.1);
   glEnd ();
};

void nmbr (int X, int Y, int N) {

   int D[][5] = {

      { 15, 9, 9, 9, 15 },
      { 1, 1, 1, 1, 1 },
      { 15, 1, 15, 8, 15 },
      { 15, 1, 3, 1, 15 },
      { 9, 9, 15, 1, 1 },
      { 15, 8, 15, 1, 15 },
      { 15, 8, 15, 9, 15 },
      { 15, 1, 1, 2, 2 },
      { 15, 9, 15, 9, 15 },
      { 15, 9, 15, 1, 15 },
   };

   for (int L = 0; L < 5; ++L) {

      int DNL = D[N][L];
      for (int LX = 3; LX >= 0; --LX) {

         if (DNL & 1) {

            quad (X + LX * 3, Y - L * 3, 2, 2);
         }
         DNL >>= 1;
      }
   }
}

void letr (int X, int Y, int C) {

   int D[][5] = {

      { 15, 9, 15, 9, 9 },
      { 14, 10, 15, 9, 15 },
      { 15, 8, 8, 8, 15 },
      { 14, 9, 9, 9, 14 },
      { 15, 8, 12, 8, 15 },
      { 15, 8, 12, 8, 8 },
      { 15, 8, 11, 9, 15 },
      { 9, 9, 15, 9, 9 },
      { 15, 4, 4, 4, 15 },
      { 15, 4, 4, 4, 12 },
      { 9, 10, 12, 10, 9 },
      { 8, 8, 8, 8, 15 },
      { 15, 15, 15, 9, 9 },
      { 13, 13, 11, 11, 9 },
      { 6, 9, 9, 9, 6 },
      { 14, 9, 14, 8, 8 },
      { 6, 9, 9, 11, 7 },
      { 15, 9, 14, 10, 9 },
      { 7, 8, 6, 1, 14 },
      { 15, 4, 4, 4, 4 },
      { 9, 9, 9, 9, 6 },
      { 9, 9, 6, 6, 4 },
      { 9, 9, 15, 15, 15 },
      { 9, 9, 6, 9, 9 },
      { 9, 10, 4, 4, 4 },
      { 15, 1, 2, 4, 15 },
   };

   C = toupper (C) - (int) 'A';
   for (int L = 0; L < 5; ++L) {

      int DNL = D[C][L];
      for (int LX = 3; LX >= 0; --LX) {

         if (DNL & 1) {

            quad (X + LX * 5, Y - L * 5, 3, 3);
         }
         DNL >>= 1;
      }
   }
}

void word (int X, int Y, const char* C) {

   int CurC = 0;
   while (C[CurC]) {

      letr (X, Y, C[CurC]);
      X += 35;
      ++CurC;
   };
}

#define NUMB 5

int BTBL[NUMB][2] = {

   { 0, 4 },
   { 0, 8 },
   { 0, 1 },
   { 1, 8 },
   { 0, 3 },
};

void blok (int B) {

   int KY = BTBL[B][0];
   int KX = BTBL[B][1];
   int X = KX * 35 + KY * 15 - 150;
   int Y = KY * -35 + 50;
//   colr (SO ? 7 : B < BLVL ? 5 : (B == BLVL ? 2 : 1));
   colr (B < BLVL ? 5 : 7);
   quad (X, Y, 12, 12);
   quad (X - 16, Y, 2, 18);
   quad (X, Y - 16, 18, 2);
   quad (X + 16, Y, 2, 18);
   quad (X, Y + 16, 18, 2);
};

void vwal (int X, int Y0, int Y1) {

   quad (X, (Y0 + Y1) / 2, 2, (Y1 - Y0) / 2);
};

void hwal (int X0, int X1, int Y) {

   quad ((X0 + X1) / 2, Y, (X1 - X0) / 2, 2);
}

void cros () {

   colr (7);
   quad (0, 0, 2, 10);
   quad (0, 0, 10, 2);
};

void circ (int X, int Y, int R) {

   int R2 = M_PI * R;
   for (int T = 0; T < R2; ++T)
      quad (X, Y, sin (M_PI * 2 * T / R2) * R, cos (M_PI * 2 * T / R2) * R);
};

void ship (int X, int Y) {

   colr (SO ? 5 : 7);
   circ (X, Y, 13);
   colr (SO ? 0 : 5);
   circ (X, Y, 10);
   colr (SO ? 5 : 7);
   circ (X, Y, 8);
}

#define NUMV 6

int VTBL[NUMV][3] = {

   { -180, -160, 160 },
   { -90, -120, 120 },
   { -27, -80, 120 },
   { 20, -80, 33 },
   { 65, -120, -20 },
   { 180, -160, 160 },
};

#define NUMH 8

int HTBL[NUMH][3] = {

   { -180, 180, -160 },
   { -90, 65, -120 },
   { -27, 20, -80 },
   { 65, 110, -70 },
   { 65, 110, -20 },
   { 20, 180, 33 },
   { -90, 120, 120 },
   { -180, 180, 160 },
};

int HDL0[] = { -90, -27, -15 };

int HDL1[] = { -90, -27, 15 };

double SX, SY;
double DX, DY;
int SXI, SYI;
bool DLO;
double DLC, DLT;
int KTF;
bool SONB;
bool CONB;
int SCORE;
int WO;
double WC;

void strt () {

   SX = -4;
   SY = -52;
   SXI = -4;
   SYI = -52;
   DX = 0;
   DY = 0;
   DLO = 0;
   DLC = 12;
   DLT = 8;
   KTF = 0;
   BLVL = 0;
   SONB = 0;
   CONB = 0;
   WO = 0;
   SO = 0;
   SC = 0.5;
   WIN = 0;
}

void dead () {

   Mix_PlayChannel (CHNL_DEAD, SND_DEAD, 0);
   Mix_HaltChannel (CHNL_LASR);

   strt ();
   SCORE = SCORE + 1;
   if (SCORE > 999) SCORE = 999;
}

void cake () {

   WIN = 1;
}

void vchk (int X, int Y0, int Y1) {

   if ((abs (SXI - X) < 12) && (SYI + 12 > Y0) && (SYI - 12 < Y1)) dead ();
}

void hchk (int X0, int X1, int Y) {

   if ((SXI + 12 > X0) && (SXI + 12 < X1) && (abs (SYI - Y) < 12)) dead ();
}

void bchk (int B) {

   int KY = BTBL[B][0];
   int KX = BTBL[B][1];
   int X = KX * 35 + KY * 15 - 150;
   int Y = KY * -35 + 50;
   int KD[] = { 116, 111, 119, 108, 114 };
   if (((SXI + 12 > X - 16) && (SXI - 12 < X + 16) && (SYI + 12 > Y - 16) && (SYI - 12 < Y + 16)) || KD[B] == KTF) {

      if (!SONB) {

         if (BLVL != B) dead ();
         else ++BLVL;
         if (BLVL == NUMB) cake ();
         Mix_PlayChannel (CHNL_BLOK, SND_BLOK, 0);
         SONB = 1;
      }
      CONB = 1;
   }
}

void game_start () {

   SND_BLOK = Mix_LoadWAV ("blok.wav");
   SND_DEAD = Mix_LoadWAV ("dead.wav");
   SND_LASR = Mix_LoadWAV ("lasr.wav");
   SND_MOVE = Mix_LoadWAV ("move.wav");
   SCORE = 0;
   strt ();
};

void game_update (double T) {

   if (WIN) {

      if (KTF == SDLK_SPACE) game_start ();
   }
   else {

      WC -= T;
      if (WC <= 0.0) {

         WC = 0.05;
         WO = !WO;
      }

      SC = SC - T;
      if (SC <= 0.0) {

         SC += 0.5;
         SO = !SO;
      }

      SX += DX * T;
      SY += DY * T;
      SXI = ((int) SX / 4) * 4;
      SYI = ((int) SY / 4) * 4;

      DLC -= T;
      if (DLC <= 0.0) {

         DLO = !DLO;
         DLC = DLT;
         if (DLT > 2.0) DLT *= 0.666;
         else if (DLT > 0.3) DLT = DLT - 0.45;
         else DLT = DLT + 0.2;

         if (DLO) {

            Mix_PlayChannel (CHNL_LASR, SND_LASR, -1);
         }
         else {

            Mix_HaltChannel (CHNL_LASR);
         }
      }

      CONB = 0;
      for (int B = 0; B < NUMB; ++B)
         bchk (B);
      if (!CONB) SONB = 0;

      for (int V = 0; V < NUMV; ++V)
         vchk (VTBL[V][0], VTBL[V][1], VTBL[V][2]);

      for (int H = 0; H < NUMH; ++H)
         hchk (HTBL[H][0], HTBL[H][1], HTBL[H][2]);

      if (DLO) hchk (HDL0[0], HDL0[1], HDL0[2]);
      hchk (HDL1[0], HDL1[1], HDL1[2]);
   }

   if (SDLK_ESCAPE == KTF) game_exit = 1;

   if (KTF) {

   }

   KTF = 0;
};

void game_render () {

   colr (0);

   for (int B = 0; B < NUMB; ++B)
      blok (B);

   ship (SXI, SYI);

   cros ();

   colr (WO ? 4 : 7);

   for (int V = 0; V < NUMV; ++V)
      vwal (VTBL[V][0], VTBL[V][1], VTBL[V][2]);

   for (int H = 0; H < NUMH; ++H)
      hwal (HTBL[H][0], HTBL[H][1], HTBL[H][2]);

   if (DLO) {

      colr (1);
      hwal (HDL0[0], HDL0[1], HDL0[2]);
   }

   colr (7);
   nmbr (-235, 160, (SCORE / 100) % 10);
   nmbr (-215, 160, (SCORE / 10) % 10);
   nmbr (-195, 160, SCORE % 10);

   if (WIN) {

      colr (7);
      quad (0, 0, 142, 82);
      colr (0);
      quad (0, 0, 140, 80);

      colr (7);
      word (-50, 70, "WIN");
      word (-120, 40, "CAKE");
      word (60, 40, "IN");

      colr (5);
      nmbr (-30, -8, (SCORE / 100) % 10);
      nmbr (-10, -8, (SCORE / 10) % 10);
      nmbr (10, -8, SCORE % 10);

      colr (7);
      word (-80, -50, "TRIES");
   }
};

void game_keypress (int K) {

   if (KTF) return;
   int NOS = 0;
   if (SDLK_UP == K) DY += 15;
   else if (SDLK_DOWN == K) DY -= 15;
   else if (SDLK_LEFT == K) DX -= 15;
   else if (SDLK_RIGHT == K) DX += 15;
   else NOS = 1;
   if (!NOS) Mix_PlayChannel (CHNL_MOVE, SND_MOVE, 0);
   KTF = K;
};
