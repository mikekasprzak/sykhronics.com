#ifndef GAME_H
#define GAME_H

void game_start ();

void game_update (double T);

void game_render ();

void game_keypress (int K);

extern bool game_exit;

#endif
