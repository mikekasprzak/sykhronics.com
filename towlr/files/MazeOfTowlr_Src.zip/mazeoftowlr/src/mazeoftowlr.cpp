#include <iostream>
#include <cstdlib>

using namespace std;

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <GL/gl.h>
#include <GL/glu.h>

#include <iostream>
#include <cstdlib>

#include "game.h"

using namespace std;

#define MIN_TICKS 20

#define MIXER_VOICES 10

SDL_Surface* screen_surface = 0;

int screen_w = 0, screen_h = 0;

int screen_open (int Width, int Height) {

   int WantBPP = SDL_GetVideoInfo ()->vfmt->BitsPerPixel;
   if (WantBPP < 15) {

      cout << "screen open warning: desktop color resolution is " << WantBPP << "; using 16 instead" << endl;
      WantBPP = 16;
   }

   // video caps
   int VFlags = SDL_OPENGL | SDL_FULLSCREEN;

   // rgb sizes we'll request depending on color depth; color mode is either 555 (for 16bpp)
   // or else 888 (for 24/32 bit)
   int RGBSize = 8;
   if (WantBPP == 15 || WantBPP == 16) RGBSize = 5;

   SDL_GL_SetAttribute (SDL_GL_RED_SIZE, RGBSize);
   SDL_GL_SetAttribute (SDL_GL_GREEN_SIZE, RGBSize);
   SDL_GL_SetAttribute (SDL_GL_BLUE_SIZE, RGBSize);

   // set up depth

   SDL_GL_SetAttribute (SDL_GL_DOUBLEBUFFER, 1);
   SDL_GL_SetAttribute (SDL_GL_STENCIL_SIZE, 0);
   SDL_GL_SetAttribute (SDL_GL_DEPTH_SIZE, 16);

   // set the graphics mode; we can't seem to detect what depth are available, so we will
   // lock the BPP and try different depth settings

   screen_surface = SDL_SetVideoMode (Width, Height, WantBPP, VFlags);

   // if we made it here then we tried everything and still no luck...
   if (!screen_surface) {

      cout << "screen open fatal: couldn't set GL mode" << endl;
      return -1;
   }

   screen_w = Width;
   screen_h = Height;

   // set lighting model to local viewer; otherwise specular reflections are going to be
   // messed up; setting to 0 might be ok for rendering stuff that is far away, but we'll
   // default to 1
   glLightModeli (GL_LIGHT_MODEL_LOCAL_VIEWER, 1);

   // default to the normal alpha blend function
   glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

   glViewport (0, 0, screen_w, screen_h);

   glMatrixMode (GL_PROJECTION);
   glLoadIdentity ();
   gluOrtho2D (-240, 240, -180, 180);

   glMatrixMode (GL_MODELVIEW);

   glEnable (GL_DEPTH_TEST);
   glDepthFunc (GL_LEQUAL);
   glShadeModel (GL_SMOOTH);

   glEnable (GL_ALPHA_TEST);
   glAlphaFunc (GL_GREATER, 0);

   return 0;
};

int audio_open () {

   int audio_rate = 44100;
   Uint16 audio_format = AUDIO_S16;
   int audio_channels = 1;
   int audio_buffers = 1024;

   SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);

   if (Mix_OpenAudio(audio_rate, audio_format, audio_channels, audio_buffers)) {

      cout << "can't open audio" << endl;
      return -1;
   }

   Mix_AllocateChannels (4);

   return 0;
}

int main (int ArgC, char* ArgV[]) {

  cout << "MAZE OF TOWLR" << endl;
  cout << "by PsySal" << endl;

   if (SDL_Init (SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER | SDL_INIT_JOYSTICK) < 0) {

      cout << "main fatal: can't initialize SDL: " << SDL_GetError() << endl;
      return -1;
   }

   SDL_EnableUNICODE (1);

   SDL_EnableKeyRepeat (SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);

   screen_open (800, 600);

   audio_open ();

   SDL_WM_SetCaption ("MAZE OF \"TOWLR\"", "MAZE OF \"TOWLR\"");

   game_start ();

   int Ticks = SDL_GetTicks ();
   while (!game_exit) {

      // wait
      int NewTicks = SDL_GetTicks ();
      int FrameTicks = NewTicks - Ticks;
      int WaitTicks = MIN_TICKS - FrameTicks;
      if( WaitTicks > 0 ) SDL_Delay( WaitTicks );
      Ticks = NewTicks;

      // update/render cycle
      double FrameTime = MIN_TICKS / 1000.0;
      glLoadIdentity ();
      game_update (FrameTime);
      game_render ();

      // swap display
      SDL_GL_SwapBuffers();
      glClearColor (0, 0, 0, 0);
      glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

      // Check if there's a pending event.
      SDL_Event E;
      while (SDL_PollEvent (&E)) {

         if (E.type == SDL_QUIT) {

            game_exit = 1;
         }
         else if (E.type == SDL_KEYDOWN) {

            game_keypress (E.key.keysym.sym);
         }
      }
   };

   SDL_Quit ();

   return 0;
};
