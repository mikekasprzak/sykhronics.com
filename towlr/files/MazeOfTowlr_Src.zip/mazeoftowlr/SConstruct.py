## SConstruct file for SCons

import os;
import string;
import sys;
import re;

BuildType = "linux"

##
## scan the given directory for source files; does not scan subdirectories
##

def scan_directory (SourceFiles, DirectoryName, BuildPrefix):

   AllFiles = os.listdir (DirectoryName)

   for CurFile in AllFiles:

      if re.search ("\.cc", CurFile) or re.search ("\.cpp", CurFile):

         SourceFiles.append (BuildPrefix + "/" + CurFile)

##
## setup environment
##

LinuxEnv = Environment (CXX="g++-4.0", CC="gcc-4.0")
LinuxEnv.Append (CXXFLAGS="-O3 -ftemplate-depth-24 -Wno-unused -I./src/util -g")
LinuxEnv.Append (LIBS=["SDL", "SDL_image", "SDL_mixer", "pthread", "GL", "GLU", "lua5.1"])
LinuxEnv.Append (LIBPATH="")
LinuxEnv.Append (LINKFLAGS="")

Win32Env = Environment (CXX="i586-mingw32msvc-g++", CC="i586-mingw32msvc-g++")
Win32Env.Append (CXXFLAGS="-O3 -ftemplate-depth-24 -Wall -I./src/util -I/usr/include/SDL -DSDLCALL=")
Win32Env.Append (LIBS=["mingw32", "SDLmain", "SDL", "SDL_mixer", "opengl32", "glu32"])
Win32Env.Append (LIBPATH="")
Win32Env.Append (LINKFLAGS="-mwindows")

if (BuildType == "linux"):

   print ("Setting environment to linux")
   BuildExt = ""
   env = LinuxEnv

elif (BuildType == "win32"):

   print ("Setting environment to win32")
   BuildExt = ".exe"
   env = Win32Env

else:

   print ("Unknown build type ``" + BuildType + "''; must be ``linux''")
   print ("--- Defaulting to linux")
   BuildType = "linux"
   env = LinuxEnv

env.BuildDir (BuildType, "src", duplicate=0)

##
## send files to scons
##

print "Scanning directories..."

SourceFiles = []
scan_directory (SourceFiles, "src", BuildType)

print "Setting program rule..."

env.Program ("mazeoftowlr" + BuildExt, SourceFiles)
