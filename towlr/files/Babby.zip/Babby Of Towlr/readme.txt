BABBY OF TOWLR
--------------
Mini-LD#5 Entry by Hamumu

Sequel to PoV's Towlr from LD #12 (The Tower)

Mini-LD#5 had the theme of "Cover", as in do a cover of someone else's game, just like how bands make covers of other band's songs.  So I covered Towlr.  The original was a frightful excursion into the depths of madness (not suitable for epileptics, by the way), and I hope that I captured the essence of that in

    BABBY OF TOWLR

The gameplay is quite different, but then, it wouldn't be Towlr if you knew what to do, would it?

YOU CAN'T FRIGTH BACK AGAINST BABBY OF TOWLR!

Inspiration by PoV
Sound FX courtesy of SFXR courtesy of DrPetter
The Rest by Hamumu

(P.S. I know you are wondering how Babby is formed, but please, don't read the code until you have won the game!  It will spoil the towlriffic fun!)