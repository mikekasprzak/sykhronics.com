#ifndef WIN_H
#define WIN_H

#include "basics.h"

void Win_Init(void);
void Win_Exit(void);

void Win(KWindow *win);

#endif