#ifndef GAME_H
#define GAME_H

#include "basics.h"

extern int tries;

void Game_Init(void);
void Game_Exit(void);

void Game(KWindow *win);

#endif