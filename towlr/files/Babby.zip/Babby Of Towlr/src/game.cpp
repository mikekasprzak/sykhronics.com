#include "game.h"
#include "input.h"
#include "sound.h"
#include "win.h"

byte quit=0;
static byte oldb;
float backR,backG;
float spd;
int tries;
byte started;
byte dead;
word startWid;

float oldMX,oldMY;

float badguyX[3];
float badguyY[3];

void Print_Number(int n)
{
	int i;
	int dig;

	dig=0;
	while(dig<3)
	{
		i=n%10;
		Image(IMG_STUFF)->blitAlphaRect((float)(0+(i*24)),24,(float)(24+(i*24)),48,400-24*(dig+1),0);
		n/=10;
		dig++;
	}
}

void Game_Render(KWindow *win)
{
	int i;

	win->setClearColor(backR,backG,0,1);
	win->setWorldView(0,0,0,1,true);

	// start zone
	DrawRect((float)(10-startWid),10,(float)(50+startWid),50,1,1,1,0.3f);
	// end zone
	DrawRect(0,390,400,400,1,1,1,0.3f);

	DrawRect(195,200,207,202,1,1,1,1);
	DrawRect(200,195,202,207,1,1,1,1);
	Image(IMG_STUFF)->blitAlphaRectFx(0,0,24,24,(short)MouseX()-12,(short)MouseY()-12,0,1,1);
	DrawRect(0,250,400,255,0,1,0,1);

	for(i=0;i<3;i++)
	{
		DrawRect(badguyX[i],badguyY[i],370,badguyY[i]+10,1,1,1,1);
	}

	if(dead)
		DrawRect(0,0,400,400,1,1,1,(float)dead/10.0f);
	Print_Number(tries);
	AltTab_BackBuffer();
}

void Lose(void)
{
	Sound(SND_DIE);
	tries++;
	backR=0;
	backG=1;
	spd=0;
	started=0;
	startWid=0;
	dead=10;
}

byte Intersect(float myY,float myY2,float yourY,float yourY2)
{
	float tmp;

	if(myY>myY2)
	{
		tmp=myY;
		myY=myY2;
		myY2=tmp;
	}

	return (myY<yourY2 && myY2>yourY);
}

byte Game_Play(KWindow *win)
{
	byte b;
	char c;
	int i;
	float msx,msy;

	msx=MouseX();
	msy=MouseY();

	if(dead)
		dead--;

	for(i=0;i<3;i++)
		if(badguyX[i]<350)
			badguyX[i]+=10;

	if(msx<0 || msx>399 || msy<0 || msy>399)
	{
		// offscreen
		if(started)
			Lose();
	}
	else
	{
		if(!started)
		{
			if(MouseX()>10 && MouseY()>10 && MouseX()<50 && MouseY()<50)
			{
				Sound(SND_START);
				started=1;
			}
		}
	
		if(started)
		{
			if(startWid<400)
				startWid++;
			if(backR<0.8f)	// not red enough
			{
				for(i=0;i<3;i++)
				{
					if(Intersect(msy,oldMY,badguyY[i],badguyY[i]+10))
					{
						badguyX[i]=0;
						Lose();
					}
				}
			}
			if(Intersect(msy,oldMY,250,255) && backG<0.8f)
				Lose();

			if(Intersect(msy,oldMY,390,400))	// yay
			{
				Sound(SND_WIN);
				Win(gameWindow);
				return 0;
			}
		}

		backR+=spd;
		if(backR>1)
		{
			backR-=1;
			Sound(SND_THROB);
		}
		backG-=spd;
		if(backG<0)
			backG+=1;

		if(spd<0.7f)
			spd+=0.00005f;

		b=MouseBtn(0);
		c=LastKeyTyped();

		if(b && !oldb)
		{
		}	
	}

	oldMX=msx;
	oldMY=msy;

	if(KeyPressed(K_VK_ESCAPE))
		return 0;

	oldb=b;
	return 1;	
}

void Game_Init(void)
{
	int i;

	quit=0;
	oldb=1;
	backR=0;
	backG=1;
	spd=0;
	tries=1;
	started=0;
	startWid=0;

	oldMX=MouseX();
	oldMY=MouseY();

	badguyY[0]=100;
	badguyY[1]=200;
	badguyY[2]=300;
	for(i=0;i<3;i++)
		badguyX[i]=350;

//	PlaySong("snd\\kid.ogg");
	KInput::hidePointer();
}

void Game_Exit(void)
{
	KInput::showPointer();
//	StopSong();
}

void Game(KWindow *win)
{
	Game_Init();
	while(!quit)
	{
		if(win->isQuit())
			quit=1;
		if(!Game_Play(win))
			quit=1;
		if(!quit)
			Game_Render(win);
	}
	Game_Exit();
}