#include "basics.h"
#include <math.h>

KWindow *gameWindow=NULL;

byte PointInRect(float px,float py,float x1,float y1,float x2,float y2)
{
	return (px>=x1 && px<=x2 && py>=y1 && py<=y2);
}

byte RectCollide(float r1x1,float r1y1,float r1x2,float r1y2,
				 float r2x1,float r2y1,float r2x2,float r2y2)
{
	return (r1x1<r2x2 && r1x2>r2x1 && r1y1<r2y2 && r1y2>r2y1);
}

float AngleFrom(float fromx,float fromy,float tox,float toy)
{
	float ang;
			
	ang=(float)atan2(-(fromy-toy),-(fromx-tox));
	ang=(ang*256.0f)/(3.14159f*2.0f);
	while(ang<0)
		ang+=256;
	while(ang>=256)
		ang-=256;
	
	return ang;
}

float TurnToward(float faceNow,float newFace,float spd)
{
	float diff,dir;

	if(newFace==faceNow)
		return faceNow;

	if(newFace>faceNow)
	{
		diff=newFace-faceNow;
		if(diff>128)
		{
			dir=-1;
			diff=256-diff;
		}
		else
			dir=1;
	}
	else
	{
		diff=faceNow-newFace;
		if(diff>128)
		{
			dir=1;
			diff=256-diff;
		}
		else
			dir=-1;
	}
	if(diff<=spd)
		return newFace;	// close enough
	else
	{
		faceNow+=spd*dir;
		while(faceNow<0)
			faceNow+=256;
		while(faceNow>=256)
			faceNow-=256;
		return faceNow;
	}
}

float Cosine(float ang)
{
	return (float)(cos(ang*3.14159f/128.0f));
}


float Sine(float ang)
{
	return (float)(sin(ang*3.14159f/128.0f));
}

float DistanceFrom(float x,float y,float x2,float y2)
{
	return (float)sqrt((x-x2)*(x-x2)+(y-y2)*(y-y2));
}

float RandFloat(float max)
{
	int r;

	r=rand()%32768;

	return (float)(((float)r)*max/32768.0f);
}

void Dampen(float *val,float amt)
{
	if((*val)>0)
	{
		(*val)-=amt;
		if((*val)<0)
			(*val)=0;
	}
	else
	{
		(*val)+=amt;
		if((*val)>0)
			(*val)=0;
	}

}

void Clamp(float *val,float max)
{
	if((*val)<-max)
		(*val)=-max;
	else if((*val)>max)
		(*val)=max;
}