#include "basics.h"
#include "sound.h"
#include "game.h"
#include "alttab.h"

byte opengl;

void InitEverything(char *cmd)
{
	char *tok;

	opengl=0;
	tok=strtok(cmd," ");
	while(tok!=NULL)
	{
		if(!strcmp(tok,"opengl"))
			opengl=1;

		tok=strtok(NULL," ");
	}

	if(opengl)
		gameWindow = KPTK::createKWindow( K_OPENGL ) ;
	else
		gameWindow = KPTK::createKWindow( K_DIRECTX ) ;
	gameWindow->createGameWindow(SCR_WID,SCR_HEI,-1,true,"BABBY OF TOWLR");
	gameWindow->setMaxFrameRate(30);
	InitSound();
	srand(timeGetTime());
	AltTab_Init();
}

void ExitEverything(void)
{
	AltTab_Exit();
	ExitSound();
	delete gameWindow;
}

int WINAPI WinMain( HINSTANCE hInst,HINSTANCE hPreInst,LPSTR lpszCmdLine,int nCmdShow)
{
	InitEverything(lpszCmdLine);
	
	Game(gameWindow);

	ExitEverything();
	return 0;
}
