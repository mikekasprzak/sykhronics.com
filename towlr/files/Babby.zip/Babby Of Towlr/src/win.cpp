#include "win.h"
#include "input.h"
#include "sound.h"
#include "game.h"

static byte quit=0;

void WinPrint_Number(int n)
{
	int i;
	int dig;

	dig=0;
	while(dig<3)
	{
		i=n%10;
		Image(IMG_STUFF)->blitAlphaRect((float)(0+(i*24)),24,(float)(24+(i*24)),48,200+36-24*(dig+1),350);
		n/=10;
		dig++;
	}
}

void Win_Render(KWindow *win)
{
	win->setClearColor(0,0,0,1);
	win->setWorldView(0,0,0,1,true);

	Image(IMG_STUFF)->blitAlphaRect(0,48,96,192,130,100);
	WinPrint_Number(tries);
	AltTab_BackBuffer();
}

byte Win_Play(KWindow *win)
{
	if(KeyPressed(K_VK_ESCAPE))
		return 0;

	if(MouseBtn(0))
		return 0;

	return 1;	
}

void Win_Init(void)
{
//	PlaySong("snd\\kid.ogg");
	KInput::hidePointer();
}

void Win_Exit(void)
{
	KInput::showPointer();
//	StopSong();
}

void Win(KWindow *win)
{
	Win_Init();
	while(!quit)
	{
		if(win->isQuit())
			quit=1;
		if(!Win_Play(win))
			quit=1;
		if(!quit)
			Win_Render(win);
	}
	Win_Exit();
}