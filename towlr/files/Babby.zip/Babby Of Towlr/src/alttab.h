#ifndef ALTTAB_H
#define ALTTAB_H

#include "basics.h"

#define IMG_STUFF	(0)
#define MAX_IMAGES	(1)

void AltTab_Init(void);
void AltTab_Exit(void);
void CheckFocus(void);
void AltTab_BackBuffer(void);

KGraphic *Image(byte w);
void DrawRect(float x,float y,float x2,float y2,float r,float g,float b,float a);
void DrawOpenRect(float x,float y,float x2,float y2,float r,float g,float b,float a,float wid);

#endif