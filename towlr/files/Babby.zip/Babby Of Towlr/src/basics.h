#ifndef BASICS_H
#define BASICS_H

#include "ptk.h"
#include "KPTK.h"
#include "ksound.h"
#include "alttab.h"

#define SCR_WID	(400)
#define SCR_HEI	(400)

extern KWindow *gameWindow;
extern byte opengl;

typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned long dword;

byte PointInRect(float px,float py,float x1,float y1,float x2,float y2);
byte RectCollide(float r1x1,float r1y1,float r1x2,float r1y2,
				 float r2x1,float r2y1,float r2x2,float r2y2);
float AngleFrom(float fromx,float fromy,float tox,float toy);
float TurnToward(float faceNow,float newFace,float spd);
float Sine(float ang);
float Cosine(float ang);
float DistanceFrom(float x,float y,float x2,float y2);
float RandFloat(float max);

void Clamp(float *val,float max);
void Dampen(float *val,float amt);

#endif