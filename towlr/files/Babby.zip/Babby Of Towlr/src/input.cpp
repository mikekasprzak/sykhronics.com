#include "input.h"

char VKNameTable[][16]={
	"Left",
	"Up",
	"Down",
	"Right",
	"Space",
	"L Shift",
	"R Shift",
	"Enter",
	"R Control",
	"L Control",
	"F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12",
	"Backspace",
	"Tab",
	"Escape",
	"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
	"0","1","2","3","4","5","6","7","8","9",
	"Num0","Num1","Num2","Num3","Num4","Num5","Num6","Num7","Num8","Num9",
	"Num *",
	"Num +",
	"Num -",
	"Num .",
	"Num /",
	"Clear",
	"Alt",
	"L Windows",
	"R Windows", 
	"NumLock",
	"ScrLock",
	";",
	"+",
	",",  
	"-",  
	".", 
	"/",     
	"`",
	"[",
	"\\",
	"]",
	"'",
	"End",
	"Home",
	"Delete",
	"Insert",
	"PrtScr",
	"PgUp",
	"PgDn",
	"- ??? -",
 };

char lastKeyTyped;
byte joy;

char *VKName(int vk)
{
	if(vk<0 || vk>K_VK_ERROR)
		return "???";

	return VKNameTable[vk];
}

bool KeyCallBack(KEvent *event)
{
	switch(event->type)
	{
		case K_EVENT_CHAR:
			lastKeyTyped=event->character;
			break;
	}
	return true;
}

char LastKeyTyped(void)
{
	char c;

	c=lastKeyTyped;
	lastKeyTyped=0;
	return c;
}

void Input_Init(KWindow *win)
{
	lastKeyTyped=0;
	win->setPTKCallBack(KeyCallBack);
	if(KInput::joyEnable(JOYSTICKID1))
		joy=1;
	else
		joy=0;
}

byte KeyPressed(int key)
{
	return (KInput::isPressed((enum EKeyboardLayout)key)==ISDOWN);
}

byte MouseBtn(byte w)
{
	if(w==0)
		return KInput::getLeftButtonState();
	else
		return KInput::getRightButtonState();
}

byte MouseIsIn(float x,float y,float x2,float y2)
{
	short msx,msy;

	msx=KInput::getMouseX();
	msy=KInput::getMouseY();

	return (msx>=x && msy>=y && msx<=x2 && msy<=y2);
}

float MouseX(void)
{
	return (float)KInput::getMouseX();
}

float MouseY(void)
{
	return (float)KInput::getMouseY();
}
