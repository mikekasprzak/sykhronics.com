#include "alttab.h"
#include "basics.h"

typedef struct imageDef_t
{
	char filename[32];
	KGraphic *kg;
	byte alpha;
} imageDef_t;

imageDef_t image[MAX_IMAGES]={
	{
		"towlr2.png",
		NULL,
		1,
	},
};

void AltTab_Init(void)
{
	int i;
	char s[32];

	for(i=0;i<MAX_IMAGES;i++)
	{
		image[i].kg=KPTK::createKGraphic();
		sprintf(s,"gfx\\%s",image[i].filename);
		image[i].kg->loadPicture(KMiscTools::makeFilePath(s),false,(image[i].alpha>0));
	}
}

void AltTab_Exit(void)
{
	int i;

	for(i=0;i<MAX_IMAGES;i++)
	{
		if(image[i].kg!=NULL)
			delete image[i].kg;
		image[i].kg=NULL;
	}
}

void AltTab_BackBuffer(void)
{
	gameWindow->flipBackBuffer(true,false);
}

void CheckFocus(void)
{
}

KGraphic *Image(byte w)
{
	return image[w].kg;
}

void DrawRect(float x,float y,float x2,float y2,float r,float g,float b,float a)
{
	Image(0)->drawRect(x,y,x2,y2,r,g,b,a);
}

void DrawOpenRect(float x,float y,float x2,float y2,float r,float g,float b,float a,float wid)
{
	Image(0)->drawRect(x,y,x2,y+wid,r,g,b,a);
	Image(0)->drawRect(x,y2-wid,x2,y2,r,g,b,a);
	Image(0)->drawRect(x,y,x+wid,y2,r,g,b,a);
	Image(0)->drawRect(x2-wid,y,x2,y2,r,g,b,a);
}