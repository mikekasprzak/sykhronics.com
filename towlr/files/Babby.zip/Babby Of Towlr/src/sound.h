#ifndef SOUND_H
#define SOUND_H

#include "basics.h"
#include "ksound.h"

#define SND_WIN	(0)
#define SND_DIE (1)
#define SND_THROB (2)
#define SND_START	(3)
#define NUM_SOUNDS	(4)

void InitSound(void);
void ExitSound(void);
void Sound(byte s);
void ToggleSound(void);
void FreqSound(byte s,float pitchPct);

void PlaySong(char *name);
void StopSong(void);

#endif