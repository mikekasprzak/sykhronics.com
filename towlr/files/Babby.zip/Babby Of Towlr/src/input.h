#ifndef INPUT_H
#define INPUT_H

#include "basics.h"

void Input_Init(KWindow *win);
char LastKeyTyped(void);
char *VKName(int vk);

byte KeyPressed(int key);
byte MouseBtn(byte w);
byte MouseIsIn(float x,float y,float x2,float y2);
float MouseX(void);
float MouseY(void);

#endif