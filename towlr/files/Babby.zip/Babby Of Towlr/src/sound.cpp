#include "sound.h"

KSound *snd[NUM_SOUNDS];
byte doSounds;
byte sndVol,musVol;

void InitSound(void)
{
	int i;
	char sndName[NUM_SOUNDS][16]={"win","die","throb","start"};
	char s[32];

	for(i=0;i<NUM_SOUNDS;i++)
	{
		snd[i]=new KSound;
		sprintf(s,"snd\\%s.wav",sndName[i]);
		snd[i]->loadSample(KMiscTools::makeFilePath(s));
	}
	sndVol=100;
	musVol=50;
	doSounds=1;
}

void ExitSound(void)
{
	int i;

	for(i=0;i<NUM_SOUNDS;i++)
		delete snd[i];
}

void Sound(byte s)
{
	if(doSounds && sndVol)
	{
		snd[s]->playSample();
	}
}

void FreqSound(byte s,float pitchPct)
{
	long freq;

	freq=(long)(44100.0f*pitchPct/100.0f);
	if(doSounds && sndVol)
	{
		snd[s]->setFrequency(freq);
		snd[s]->playSample();
	}
}

void ToggleSound(void)
{
	doSounds=1-doSounds;
}

KSound *song=NULL;
void PlaySong(char *name)
{
	if(song!=NULL)
		delete song;
	song=new KSound;
	song->loadStream(KMiscTools::makeFilePath(name));
	song->playStream(true);
}

void StopSong(void)
{
	if(song!=NULL)
		delete song;
	song=NULL;
}
