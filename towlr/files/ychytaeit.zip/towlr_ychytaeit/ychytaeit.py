#!/usr/bin/python

# UGH!  THIS IS A MESS BECAUSE IT WAS ORIGINALLY A VERY DIFFERENT GAME.
# WOW, WHAT A HACKED TOGETHER PEICE OF GARBAGE!

import pygame
import random
import math

win_size = (640,480)
bg_color = (0,0,0)

frame_wait = 17
enemy_count = 1

pygame.init()
disp = pygame.display.set_mode(win_size, pygame.DOUBLEBUF)
pygame.mouse.set_visible(False)
pygame.display.set_caption("You Can't Have Your Towlr and Eat it Too")

font = pygame.font.SysFont(None, 25)

dirs = ((1,0), (-1,0), (0,-1), (0,1))


def sqr_len(pos1, pos2):
	return (pos2[0]-pos1[0])**2 + (pos2[1]-pos1[1])**2


class Obj(object):
	def __init__(self):
		super(Obj, self).__init__()
		self.x = 0
		self.y = 0
		self.radious = 0.0
		
	def draw(self):
		pass
		
	def update(self):
		pass
		
	def intersect(self, other):
		r = other.radious + self.radious
		if abs(other.x - self.x) < r:
			if abs(other.y - self.y) < r:
				l = sqr_len((self.x, self.y), (other.x, other.y))
				return l < (self.radious + other.radious) ** 2
		return False
		

class Enemy(Obj):
	def __init__(self):
		super(Enemy, self).__init__()
		self.x = random.randint(0, win_size[0])
		self.y = random.randint(0, win_size[1])
		self.radious = 3.0
		self.dir = random.choice(dirs)
		self.step = random.randint(10,50)
		
	def draw(self):
		pygame.draw.circle(disp, (255,0,0), (self.x, self.y), 3)
		
	def update(self):
		self.step -= 1
		if self.step == 0:
			self.step = random.randint(10,50)
			self.dir = random.choice(dirs)
		
		ox = self.x
		oy = self.y
			
		self.x += self.dir[0]
		self.y += self.dir[1]
		
		if (self.x < 0) or (self.x > win_size[0]):
			self.x = ox
			self.dir = random.choice(dirs)
			
		if (self.y < 0) or (self.y > win_size[1]):
			self.y = oy
			self.dir = random.choice(dirs)
		
		if (shield.active):
			if self.intersect(shield):
				self.x = ox
				self.y = oy
				self.dir = random.choice(dirs)
				
		if self.intersect(hero):
			try_again()

		
class Hero(Obj):
	def __init__(self):
		super(Hero, self).__init__()
		self.radious = 20.0
		self.xo = 0
		self.yo = 0
		
	def draw(self):
		pygame.draw.circle(disp, (0,128,255), (self.x, self.y), int(self.radious))
		
	def update(self):
		if not target.was_pressed:
			self.x = max(mouse_pos[0],320)
			self.y = mouse_pos[1]
		#self.radious += 0.1
		'''
		if not shield.active:
			if mouse_press[0]:
				#s = Shield()
				shield.set((self.x, self.y), int(self.radious))
				#obj_list.append(s)
				self.radious = 20.0
		'''
		

class Shield(Obj):
	def __init__(self):
		super(Shield, self).__init__()
		self.radious = 0
		self.intensity = 255
		self.active = False
	
	def draw(self):	
		if self.active:
			pygame.draw.circle(disp, (0,self.intensity,0), (self.x, self.y), self.radious, 1)
		
	def update(self):
		self.intensity -= 1
		if self.intensity < 0:
			self.intensity = 0
			self.active = False
			
	def set(self, pos, rad):
		if not self.active:
			self.x = pos[0]
			self.y = pos[1]
			self.radious = rad
			self.intensity = 255
			self.active = True
			
			
class Target(Obj):
	def __init__(self):
		super(Target, self).__init__()
		#self.x = random.randint(0, win_size[0])
		#self.y = random.randint(0, win_size[1])
		self.x = 10
		self.y = win_size[1] / 2
		self.radious = 10.0
		self.rect = pygame.Rect(self.x - 10, self.y - 10, 20, 20)
		self.was_pressed = False
		
	def draw(self):
		pygame.draw.rect(disp, (255,255,0), self.rect)
		
	def update(self):
		if self.intersect(base):
			#if connect_code == win_code:
			#	pass
			#else:
			#if connect_code != "":
			#	try_again()
			sin_block.active = True
			self.was_pressed = True
				
			#self.x = random.randint(0, win_size[0])
			#self.y = random.randint(0, win_size[1])
			#self.radious = 6.0
			#self.rect = pygame.Rect(self.x - 3, self.y - 3, 6, 6)
			
			#for i in xrange(enemy_count):
			#	obj_list.append(Enemy())
				
			#obj_list.append(Connector())


class BtnConnector(Obj):
	def __init__(self):
		super(BtnConnector, self).__init__()
		self.x = win_size[0] - 10
		self.y = 10
		self.radious = 6.0
		self.rect = pygame.Rect(self.x - 3, self.y - 3, 6, 6)
		self.active = True
		
	def draw(self):
		if self.active:
			pygame.draw.rect(disp, (255,255,0), self.rect)
		else:
			pygame.draw.rect(disp, (128,128,0), self.rect)
		
	def update(self):
		if self.active:
			if self.intersect(hero):
				obj_list.append(Connector())
				self.active = False
				snd_ding.play()


class BtnEnemy(Obj):
	def __init__(self):
		super(BtnEnemy, self).__init__()
		self.x = win_size[0] - 10
		self.y = win_size[1] - 10
		self.radious = 6.0
		self.rect = pygame.Rect(self.x - 3, self.y - 3, 6, 6)
		self.active = True
		self.countdown = 0
		
	def draw(self):
		if self.active:
			pygame.draw.rect(disp, (255,255,0), self.rect)
		else:
			pygame.draw.rect(disp, (128,128,0), self.rect)
		
	def update(self):
		self.countdown -= 1
		if self.countdown <= 0:
			self.active = True
			
		if self.active:
			if self.intersect(hero):
				obj_list.append(Enemy())
				self.active = False
				self.countdown = 50
				guide.lightness += 8
				if guide.lightness > 255:
					guide.lightness = 255
				snd_ding.play()


class Connector(Obj):
	def __init__(self):
		super(Connector, self).__init__()
		self.x = win_size[0] / 2
		self.y = win_size[1] / 2
		self.xo = 0
		self.yo = 0
		self.radious = 0.0
		self.state = 0
	
	def draw(self):
		pygame.draw.circle(disp, (255,128,0), (self.x, self.y), int(self.radious))
		
	def update(self):
		global base, connect_code
		
		self.radious += 1.0
		
		if self.radious > 10.0:
			self.radious = 10.0
			
		if self.state == 0:
			if self.intersect(base):
				btn_connector.active = True
				self.state = 1
				a = math.atan2((self.y-base.y),(self.x-base.x))
				a = math.radians(round(math.degrees(a)/45))*45
				self.xo = int(base.xo + math.cos(a) * (10.0 + base.radious))
				self.yo = int(base.yo + math.sin(a) * (10.0 + base.radious))
				#self.xo = self.x - hero.x
				#self.yo = self.y - hero.y
				base = self
				connect_code += "%i" % (((math.degrees(a) / 45)+4)%8)
				#connect_code += "%i" % (a + 4)
				snd_biff.play()
		else:
			self.x = hero.x + self.xo
			self.y = hero.y + self.yo
			
			if sin_block.check_hit(self.x, self.y):
				try_again()
				
			

class SinBlock(Obj):
	def __init__(self):
		super(SinBlock,self).__init__()
		self.offset = 0
		self.gap = 300
		self.gd = -20
		self.active = False
		
	def check_hit(self, px, py):
		if (px > 300) or (not self.active):
			return False
			
		y = math.sin(px * 0.02) * 50
		m = win_size[1]/2 + y
		return (py < m - self.gap) or (py > m + self.gap)
		
	def draw(self):
		#pygame.draw.rect(disp, (255,255,255), (self.x,self.y+self.offset,300,70))
		#pygame.draw.rect(disp, (255,255,255), (self.x,0,300,win_size[1]))
		for i in xrange(15):
			y = math.sin((i*20+10) * 0.02) * 50
			#rect = pygame.Rect(self.x+i*20, win_size[1]/2 + y - self.gap, 20, self.gap*2)
			#pygame.draw.rect(disp, (screen_color,0,0), rect)
			rect = pygame.Rect(self.x+i*20+10, y - self.gap-100, 2, win_size[1]/2+100)
			pygame.draw.rect(disp, (255,255,255), rect)
			
			rect = pygame.Rect(self.x+i*20+10, win_size[1]/2 + y + self.gap, 2, win_size[1]/2+100)
			pygame.draw.rect(disp, (255,255,255), rect)
			
	def update(self):
		global win
		
		if self.active:
			self.gap += self.gd
			if (self.gap > 300):
				self.gap = 300
				self.gd = -20
				self.active = False
				if target.was_pressed:
					win = True
					snd_win.play()
			
			if (self.gap < 35):
				self.gap = 35
				self.gd = 1
				
				
class Guide(Obj):
	def __init__(self):
		super(Guide, self).__init__()
		self.x = 300
		self.lightness = 0
		
	def draw(self):
		if self.lightness > 0:
			for i in xrange(14):
				y1 = win_size[1]/2 + math.sin((i*20+10) * 0.02) * 50
				y2 = win_size[1]/2 + math.sin(((i+1)*20+10) * 0.02) * 50
				x1 = self.x+i*20+10
				x2 = self.x+(i+1)*20+10
				
				pygame.draw.line(disp, (self.lightness,self.lightness,self.lightness), (x1,y1), (x2,y2))

class Plus(Obj):
	def __init__(self):
		super(Plus, self).__init__()
		self.x = win_size[0] / 2
		self.y = win_size[1] / 2
		
	def draw(self):
		pygame.draw.rect(disp, (64,64,64), (self.x-15, self.y-3, 30, 6))
		pygame.draw.rect(disp, (64,64,64), (self.x-3, self.y-15, 6, 30))
		

hero = Hero()
shield = Shield()
target = Target()
plus = Plus()
base = hero
btn_connector = BtnConnector()
btn_enemy = BtnEnemy()
sin_block = SinBlock()
guide = Guide()
obj_list = []
screen_color = 0
connect_code = ""

snd_ding = pygame.mixer.Sound("ding.wav")
snd_biff = pygame.mixer.Sound("biff.wav")
snd_lose = pygame.mixer.Sound("lose.wav")
snd_win = pygame.mixer.Sound("win.wav")

win_msg = [
"Congratulations, I'm proud of you.",
"For your hard work and ingenuity I",
"award you with a nice three tier",
"wedding cake.  The bride and groom",
"this cake was stolen from had to",
"serve hotdogs to their guests",
"instead.  Eat quickly, for this",
"cake has LoJack."]

win_surfs = []
for m in win_msg:
	win_surfs.append(font.render(m, True, (255,255,255)))


def try_again():
	global tries, obj_list, base, connect_code, screen_color,resetting
	if not resetting:
		resetting = True
		tries += 1
		obj_list = []
		base = hero
		connect_code = ""
		screen_color = 255
		btn_connector.active = True
		guide.lightness = 0
		target.was_pressed = False
		snd_lose.play()
	

mouse_press = [False, False, False]

tries = 1
win = False
done = False
while not done:
	t = pygame.time.get_ticks()
	resetting = False
	
	key = pygame.key.get_pressed()
	mouse_pos = pygame.mouse.get_pos()
	mouse_press = pygame.mouse.get_pressed()
	
	if not win:
		screen_color -= 4
		if screen_color < 0:
			screen_color = 0
		disp.fill((screen_color, 0, 0))
		
		pygame.draw.line(disp, (100,100,100),(300,0),(300,win_size[0]))
		
		guide.draw()
		plus.draw()
		
		sin_block.update()
		sin_block.draw()
		
		btn_connector.update()
		btn_connector.draw()
		
		btn_enemy.update()
		btn_enemy.draw()
		
		target.update()
		target.draw()
		
		shield.update()
		shield.draw()
		
		hero.update()
		hero.draw()
		
		for o in obj_list:
			o.update()
			o.draw()
			
		score_surf = font.render("%i" % tries, True, (255,255,255))
		disp.blit(score_surf, (0,0))
	else:
		disp.fill((0, 0, 0))
		y = 10
		for m in win_surfs:
			disp.blit(m, (10,y))
			y += m.get_height()
			
		score_surf = font.render("You won cake in %i tries." % tries, True, (255,255,255))
		disp.blit(score_surf, (10,200))
			
		pygame.draw.rect(disp, (0,128,255), (350,75,30,70))
		pygame.draw.rect(disp, (255,255,255), (410,75,30,70))
		pygame.draw.rect(disp, (255,255,128), (300,150,200,95))
		pygame.draw.rect(disp, (255,255,128), (250,250,300,95))
		pygame.draw.rect(disp, (255,255,128), (200,350,400,95))
	
	pygame.display.flip()
	
	if key[pygame.K_ESCAPE]:
		done = True
			
	for event in pygame.event.get():
		if event.type == pygame.QUIT: 
			done = True
		
	td = pygame.time.get_ticks() - t
	pygame.time.wait(frame_wait - td)
